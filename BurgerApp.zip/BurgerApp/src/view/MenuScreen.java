﻿    package view;

    import model.OrderItem;
    import javax.swing.*;
    import javax.swing.border.EmptyBorder;
    import java.awt.*;
    import java.net.URL;
    import java.util.function.Consumer;

    public class MenuScreen extends JPanel {

        private JLabel cartCountLabel;

        public MenuScreen(Runnable onBackToWelcome, Runnable onOpenCart, Consumer<OrderItem> onAddToCart) {
            // ใช้ GridBagLayout เพื่อจัด Container ตรงกลางให้อยู่จุดศูนย์กลางเสมอไม่ว่าจะยืดหรือหดจอ
            setLayout(new GridBagLayout());
            
            // ขอบภายนอกเป็นสีดำสนิท
            setBackground(Color.BLACK);

            // สร้าง Container หลักสำหรับเนื้อหา
            JPanel menuContainer = new JPanel(new BorderLayout()) {
                @Override
                public Dimension getPreferredSize() {
                    // คำนวณขนาดที่เหมาะสมตามขนาดหน้าจอหลักอัตโนมัติ
                    Container parent = getParent();
                    if (parent != null) {
                        int pWidth = parent.getWidth();
                        int pHeight = parent.getHeight();
                        if (pWidth > 0 && pHeight > 0) {
                            // กำหนดความกว้างสูงสุดไม่เกิน 500px เพื่อคงสไตล์ UI แอพมือถือ/แท็บเล็ต
                            int targetW = Math.min(pWidth, 500); 
                            int targetH = Math.min(pHeight, 900);
                            return new Dimension(targetW, targetH);
                        }
                    }
                    return new Dimension(480, 860);
                }
            };

            menuContainer.setOpaque(true);
            menuContainer.setBackground(Color.WHITE);

            // Header Panel
            JPanel headerPanel = new JPanel(new BorderLayout());
            headerPanel.setOpaque(false);
            headerPanel.setBorder(new EmptyBorder(10, 12, 8, 12));

            // --- แก้ไขจุดนี้: เปลี่ยนปุ่มย้อนกลับเป็นไอคอน Return.jpg ---
            JButton backBtn = new JButton();
            ImageIcon returnIcon = getResizedIcon("/assets/Return.jpg", 58, 58);
            if (returnIcon != null) {
                backBtn.setIcon(returnIcon);
            } else {
                backBtn.setText("←"); // Fallback กรณีไม่พบรูปภาพ
                backBtn.setFont(new Font("Arial", Font.BOLD, 28));
                backBtn.setForeground(new Color(75, 65, 65));
            }
            backBtn.setFocusPainted(false);
            backBtn.setBorderPainted(false);
            backBtn.setContentAreaFilled(false);
            backBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            backBtn.addActionListener(e -> onBackToWelcome.run());

            JLabel logoLabel = createCenteredImageLabel("/assets/CDNP BURGER.png", 220, 40);

            JPanel rightHeader = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
            rightHeader.setOpaque(false);

            JButton cartBtn = new JButton("🛒");
            cartBtn.setFont(new Font("SansSerif", Font.PLAIN, 22));
            cartBtn.setFocusPainted(false);
            cartBtn.setBorderPainted(false);
            cartBtn.setContentAreaFilled(false);
            cartBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            cartBtn.addActionListener(e -> onOpenCart.run());

            cartCountLabel = new JLabel("0");
            cartCountLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            cartCountLabel.setForeground(Color.WHITE);  
            cartCountLabel.setHorizontalAlignment(SwingConstants.CENTER);
            cartCountLabel.setOpaque(true);
            cartCountLabel.setBackground(new Color(190, 0, 0));
            cartCountLabel.setPreferredSize(new Dimension(22, 22));

            rightHeader.add(cartBtn);
            rightHeader.add(cartCountLabel);

            headerPanel.add(backBtn, BorderLayout.WEST);
            headerPanel.add(logoLabel, BorderLayout.CENTER);
            headerPanel.add(rightHeader, BorderLayout.EAST);

            // Title Area
            JPanel titleArea = new JPanel();
            titleArea.setOpaque(false);
            titleArea.setLayout(new BoxLayout(titleArea, BoxLayout.Y_AXIS));

            JLabel titleText = new JLabel("Order your favourite food!");
            titleText.setFont(new Font("Serif", Font.PLAIN, 20));
            titleText.setForeground(new Color(30, 30, 30));
            titleText.setAlignmentX(Component.CENTER_ALIGNMENT);

            JButton menuPillBtn = new JButton("MENU");
            menuPillBtn.setFont(new Font("Serif", Font.BOLD, 22));
            menuPillBtn.setForeground(Color.WHITE);
            menuPillBtn.setBackground(new Color(105, 90, 90));
            menuPillBtn.setFocusPainted(false);
            menuPillBtn.setBorderPainted(false);
            menuPillBtn.setPreferredSize(new Dimension(170, 46));
            menuPillBtn.setMaximumSize(new Dimension(170, 46));
            menuPillBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

            titleArea.add(titleText);
            titleArea.add(Box.createRigidArea(new Dimension(0, 8)));
            titleArea.add(menuPillBtn);

            JPanel headerWrapper = new JPanel(new BorderLayout());
            headerWrapper.setOpaque(false);
            headerWrapper.add(headerPanel, BorderLayout.NORTH);
            headerWrapper.add(titleArea, BorderLayout.CENTER);

            // Grid Panel 3 คอลัมน์
            JPanel gridPanel = new JPanel(new GridLayout(0, 3, 8, 12));
            gridPanel.setOpaque(false);
            gridPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

            // รายชื่อเบอร์เกอร์ + ราคา
            Object[][] products = {
                {"Chicken Burger", "/assets/Chicken Burger.png", 50.0},
                {"Fried Chicken", "/assets/Fried Chicken.png", 50.0},
                {"Egg and cheese", "/assets/Egg and cheese.png", 50.0},
                {"Beef + Shrimp", "/assets/Beef + Shrimp.png", 60.0},
                {"Super Fish", "/assets/Super Fish.png", 55.0},
                {"Black Sauce Burger", "/assets/Black Sauce Burger.png", 50.0},
                {"Spicy burger cries", "/assets/Spicy burger cries.png", 50.0},
                {"Monster Triple", "/assets/Monster Triple.png", 100.0},
                {"Veggie Burger", "/assets/Veggie Burger.png", 65.0}
            };

            for (Object[] prod : products) {
                String name = (String) prod[0];
                String path = (String) prod[1];
                double price = (double) prod[2];
                gridPanel.add(createFoodCard(name, path, price, onAddToCart));
            }

            // ScrollPane แบบไดนามิก ซ่อน ScrollBar แนวนอน
            JScrollPane scrollPane = new JScrollPane(gridPanel);
            scrollPane.setOpaque(false);
            scrollPane.getViewport().setOpaque(false);
            scrollPane.setBorder(null);
            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            scrollPane.getVerticalScrollBar().setUnitIncrement(16);

            menuContainer.add(headerWrapper, BorderLayout.NORTH);
            menuContainer.add(scrollPane, BorderLayout.CENTER);

            // ใช้ GridBagConstraints เพื่อบังคับให้อยู่ตรงกลาง
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.anchor = GridBagConstraints.CENTER;
            
            add(menuContainer, gbc);
        }

        public void updateCartBadge(int totalCount) {
            if (cartCountLabel != null) {
                cartCountLabel.setText(String.valueOf(totalCount));
            }
        }

        private JPanel createFoodCard(String burgerName, String resourcePath, double price, Consumer<OrderItem> onAddToCart) {
            JPanel cardContainer = new JPanel(new BorderLayout(0, 3));
            cardContainer.setOpaque(true);
            cardContainer.setBackground(Color.WHITE);
            cardContainer.setBorder(BorderFactory.createLineBorder(new Color(225, 220, 215)));

            Image img = loadImage(resourcePath);

            JLabel imgLabel = new JLabel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    if (img != null && img.getWidth(this) > 0 && img.getHeight(this) > 0) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

                        int labelW = getWidth();
                        int labelH = getHeight();
                        double scale = Math.min((double) labelW / img.getWidth(this), (double) labelH / img.getHeight(this));

                        int drawW = (int) (img.getWidth(this) * scale);
                        int drawH = (int) (img.getHeight(this) * scale);
                        int x = (labelW - drawW) / 2;
                        int y = (labelH - drawH) / 2;

                        g2.drawImage(img, x, y, drawW, drawH, this);
                        g2.dispose();
                    }
                }
            };

            JLabel nameLabel = new JLabel(burgerName, SwingConstants.CENTER);
            nameLabel.setFont(new Font("Tahoma", Font.BOLD, 10));

            JLabel priceLabel = new JLabel(String.format("฿%.0f", price), SwingConstants.CENTER);
            priceLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
            priceLabel.setForeground(new Color(180, 40, 40));

            JButton addBtn = new JButton("+ ตะกร้า");
            addBtn.setFont(new Font("Tahoma", Font.BOLD, 10));
            addBtn.setForeground(Color.WHITE);
            addBtn.setBackground(new Color(105, 90, 90));
            addBtn.setFocusPainted(false);
            addBtn.setBorderPainted(false);
            addBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            addBtn.addActionListener(e -> onAddToCart.accept(new OrderItem(burgerName, resourcePath, price, 1)));

            cardContainer.add(imgLabel, BorderLayout.CENTER);

            JPanel bottom = new JPanel(new GridLayout(3, 1, 1, 2));
            bottom.setOpaque(false);
            bottom.setBorder(new EmptyBorder(2, 4, 4, 4));
            bottom.add(nameLabel);
            bottom.add(priceLabel);
            bottom.add(addBtn);

            cardContainer.add(bottom, BorderLayout.SOUTH);

            return cardContainer;
        }

        private JLabel createCenteredImageLabel(String resourcePath, int targetW, int targetH) {
            Image img = loadImage(resourcePath);
            JLabel label = new JLabel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    if (img != null && img.getWidth(this) > 0 && img.getHeight(this) > 0) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

                        double scale = Math.min((double) getWidth() / img.getWidth(this), (double) getHeight() / img.getHeight(this));
                        int drawW = (int) (img.getWidth(this) * scale);
                        int drawH = (int) (img.getHeight(this) * scale);
                        int x = (getWidth() - drawW) / 2;
                        int y = (getHeight() - drawH) / 2;

                        g2.drawImage(img, x, y, drawW, drawH, this);
                        g2.dispose();
                    }
                }
            };
            label.setPreferredSize(new Dimension(targetW, targetH));
            return label;
        }

        private Image loadImage(String path) {
            URL imgURL = getClass().getResource(path);
            if (imgURL != null) {
                return new ImageIcon(imgURL).getImage();
            } else {
                System.err.println("ไม่พบไฟล์รูปภาพ: " + path);
                return null;
            }
        }

        // --- เพิ่มฟังก์ชัน Helper สำหรับปรับขนาดรูปภาพปุ่มย้อนกลับ ---
        private ImageIcon getResizedIcon(String path, int width, int height) {
            URL imgURL = getClass().getResource(path);  
            if (imgURL != null) {
                ImageIcon icon = new ImageIcon(imgURL);
                Image img = icon.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
                return new ImageIcon(img);
            }
            return null;
        }
    }
        